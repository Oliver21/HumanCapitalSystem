/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Tony
 */
import logic.Candidato;
import logic.CandidatoIO;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AgregarCandidatoListServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        
        // get parameters from the request
        Candidato cand = new Candidato();
        cand.sNombreCompleto = request.getParameter("nombre");
        cand.sDomicilio = request.getParameter("domicilio");
        cand.sTelefono = request.getParameter("telefono");
        cand.sCorreoElectronico = request.getParameter("correo");
        cand.sTituloProfesional = request.getParameter("titulo");
        cand.sUniversidad = request.getParameter("universidad");
        cand.sCertificados = request.getParameter("certificado");
        cand.sTrabajosAnteriores = request.getParameter("trabajos");
        cand.sExpectativas = request.getParameter("economico");

        // get a relative file name
        ServletContext context = getServletContext();
        ServletConfig config = getServletConfig();
        String relativePath = config.getInitParameter("relativePathToFile");
        String path = context.getRealPath(relativePath);
        // use regular Java classes
        CandidatoIO.addRecord(cand, path);
        // forward request and response objects to JSP page
        String url = "/candidatos.jsp";
        RequestDispatcher dispatcher
                = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
