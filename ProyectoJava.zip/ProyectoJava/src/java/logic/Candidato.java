package logic;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Tony
 */
public class Candidato {
    public String sNombreCompleto;
    public String sDomicilio;
    public String sTelefono;
    public String sCorreoElectronico;
    public String sTituloProfesional;
    public String sUniversidad;
    public String sCertificados;
    public String sTrabajosAnteriores;
    public String sExpectativas;

    public Candidato() {
        this.sNombreCompleto = "";
        this.sDomicilio = "";
        this.sTelefono = "";
        this.sCorreoElectronico = "";
        this.sTituloProfesional = "";
        this.sUniversidad = "";
        this.sCertificados = "";
        this.sTrabajosAnteriores = "";
        this.sExpectativas = "";
    }
    
    public String sDescripcion(){
        String sResultado = "";
        sResultado += "Nombre: " + this.sNombreCompleto;
        sResultado += "Domicilio: " + this.sDomicilio;
        sResultado += "Telefono: " + this.sTelefono;
        sResultado += "Correo: " + this.sCorreoElectronico;
        sResultado += "Titulo: " + this.sTituloProfesional;
        sResultado += "Universidad: " + this.sUniversidad;
        sResultado += "Certificados: " + this.sCertificados;
        sResultado += "Trabajos anteriores: " + this.sTrabajosAnteriores;
        sResultado += "Expectativas: " + this.sExpectativas;
        
        return sResultado;
    }
}
