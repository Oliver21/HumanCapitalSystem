package logic;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 *
 * @author Tony
 */
public class CandidatoIO {
    public static void addRecord(Candidato cand, String filename) throws IOException
    {
        File file = new File(filename);
        PrintWriter out = new PrintWriter(
                new FileWriter(file, true));
        out.println(cand.sNombreCompleto + "|"
                + cand.sDomicilio + "|"
                + cand.sTelefono + "|"
                + cand.sCorreoElectronico + "|"
                + cand.sTituloProfesional + "|"
                + cand.sUniversidad + "|"
                + cand.sCertificados + "|"
                + cand.sTrabajosAnteriores + "|"
                + cand.sExpectativas);
        out.close();
    }
    
    public static ArrayList<Candidato> readRecords(String file) throws IOException
    {
        ArrayList<Candidato> cands = new ArrayList<Candidato>();
        BufferedReader in = new BufferedReader(
                new FileReader(file));
        String line = in.readLine();
        while (line != null)
        {
            Candidato cand = new Candidato();
            StringTokenizer t = new StringTokenizer(line, "|");
            cand.sNombreCompleto = t.nextToken();
            cand.sDomicilio = t.nextToken();
            cand.sTelefono = t.nextToken();
            cand.sCorreoElectronico = t.nextToken();
            cand.sTituloProfesional = t.nextToken();
            cand.sUniversidad = t.nextToken();
            cand.sCertificados = t.nextToken();
            cand.sTrabajosAnteriores = t.nextToken();
            //cand.sExpectativas = t.nextToken();
            
            cands.add(cand);
            line = in.readLine();
        }
        in.close();
        return cands;
    }
}
